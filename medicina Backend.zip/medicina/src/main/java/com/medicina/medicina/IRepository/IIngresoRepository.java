package com.medicina.medicina.IRepository;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.medicina.medicina.Entity.Ingreso;


public interface IIngresoRepository extends JpaRepository<Ingreso, Long>{
		@Query(value="select count(*) from ingresos  where  estado =true and id_paciente=:idPaciente",nativeQuery = true )
		Double verificacion(Long idPaciente);
		
		@Query(value="select count(*) from ingresos where estado =true and  cama=:numeroCama",nativeQuery = true)
		Double validacion(String numeroCama);
		
		@Query(value="SELECT i.* "
				+ " FROM ingresos i "
				+ " INNER JOIN medico md ON i.id_medico = md.id "
				+ " INNER JOIN pacientes pt ON i.id_paciente = pt.id "
				+ " WHERE "
				+ "( "
				+ "    :search IS NULL "
				+ "    OR TO_CHAR(i.fecha_ingreso, 'YYYY-MM-DD') LIKE '%' || :search || '%' "
				+ "    OR TO_CHAR(i.fecha_salida, 'YYYY-MM-DD') LIKE '%' || :search || '%' "
				+ "    OR i.cama LIKE '%' || :search || '%' "
				+ "    OR i.habitacion LIKE '%' || :search || '%' "
				+ "    OR CONCAT(md.primer_nombre, ' ', md.primer_apellido) LIKE '%' || :search || '%' "
				+ "    OR CONCAT(pt.primer_nombre, ' ', pt.primer_apellido) LIKE '%' || :search || '%')", nativeQuery = true)
		Page<Ingreso> getDatatable(Pageable pageable, String search);
}
