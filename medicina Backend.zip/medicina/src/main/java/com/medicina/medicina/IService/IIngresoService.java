package com.medicina.medicina.IService;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.medicina.medicina.Entity.Ingreso;

public interface IIngresoService {
	
	
	public List <Ingreso> all();
	public Optional <Ingreso> findById(Long id);
	public Ingreso save (Ingreso Ingresos)throws Exception;
	public void update (Long id, Ingreso ingreso) throws Exception;
	public void delete (Long id);
	public Page<Ingreso> getDatatable(Pageable pageable, String search) throws Exception;
}
