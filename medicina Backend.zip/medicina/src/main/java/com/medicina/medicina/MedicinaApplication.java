package com.medicina.medicina;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicinaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicinaApplication.class, args);
	}

}
