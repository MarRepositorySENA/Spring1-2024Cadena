package com.medicina.medicina;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicinaApplicationTests {

	@Test
	void contextLoads() {
	}

}
